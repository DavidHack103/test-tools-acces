# Installer

# Run
```
cd Installer
bash installer
```
